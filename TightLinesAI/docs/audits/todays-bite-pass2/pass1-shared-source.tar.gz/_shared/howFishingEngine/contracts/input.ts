/**
 * Shared engine input — ENGINE_REBUILD_MASTER_PLAN § Shared input contract
 * Optional fields beyond the doc snippet are allowed for richer normalization (e.g. precip rate).
 */

import type { EngineContext } from "./context.ts";
import type { RegionKey } from "./region.ts";

export type SharedEngineRequest = {
  latitude: number;
  longitude: number;
  state_code: string | null;
  region_key: RegionKey;
  local_date: string;
  local_timezone: string;
  context: EngineContext;
  environment: {
    current_air_temp_f?: number | null;
    daily_mean_air_temp_f?: number | null;
    measured_water_temp_f?: number | null;
    measured_water_temp_24h_ago_f?: number | null;
    measured_water_temp_72h_ago_f?: number | null;
    measured_water_temp_source?: string | null;
    /** Forecast calendar-day low/high (°F), same index as 7-day arrays — for UI + narration only. */
    daily_low_air_temp_f?: number | null;
    daily_high_air_temp_f?: number | null;
    prior_day_mean_air_temp_f?: number | null;
    day_minus_2_mean_air_temp_f?: number | null;
    pressure_mb?: number | null;
    /** Hourly slots, oldest first; retain null slots for missing readings. */
    pressure_history_mb?: (number | null)[] | null;
    wind_speed_mph?: number | null;
    cloud_cover_pct?: number | null;
    precip_24h_in?: number | null;
    precip_72h_in?: number | null;
    precip_7d_in?: number | null;
    active_precip_now?: boolean | null;
    /** Optional — improves precip disruption when present */
    precip_rate_now_in_per_hr?: number | null;
    /** Target local day has later thunderstorm weather-code evidence. */
    storm_risk_later_today?: boolean | null;
    /** Target local day has meaningful later rain/weather risk. */
    rain_risk_later_today?: boolean | null;
    /** Target local day has a heavy rain signal later, not trace rain. */
    heavy_rain_later_today?: boolean | null;
    /** First local hour with later storm/rain evidence, when hourly data can identify it. */
    storm_window_start_local_hour?: number | null;
    /** Max precip probability for the target local day, when available. */
    max_precip_probability_pct?: number | null;
    tide_movement_state?: string | null;
    tide_station_id?: string | null;
    /** Strongest current speed (kt) today when available */
    current_speed_knots_max?: number | null;
    /** Hourly tide height (ft) for 3h swing — optional */
    tide_height_hourly_ft?: number[] | null;
    /** CO-OPS high/low events for intra-day movement proxy */
    tide_high_low?:
      | Array<{ time: string; value: number; type?: string }>
      | null;
    sunrise_local?: string | null;
    sunset_local?: string | null;
    solunar_peak_local?: string[] | null;
    /** 24 values, local hour 0–23 from midnight on local_date — optional timing refinement */
    hourly_air_temp_f?: number[] | null;
    hourly_cloud_cover_pct?: number[] | null;
  };
  data_coverage: {
    source_notes?: string[];
  };
};
