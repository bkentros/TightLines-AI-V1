import type { VariableState } from "../contracts/mod.ts";
import { clampEngineScore, pieceLinear } from "../score/engineScoreMath.ts";

/** Per VARIABLE_THRESHOLDS — sparse history downgrades reliability one level */
export type PressureHistoryQuality = "two_point" | "sparse" | "adequate";

export type PressureNormalizeResult = {
  state: VariableState;
  quality: PressureHistoryQuality;
};

/**
 * Rolling ~3h pressure swing: assume hourly samples when length 8–49; else scale lag to ~3h span.
 */
function maxRolling3hSwingMb(series: (number | null)[]): number {
  const n = series.length;
  if (n < 2) return 0;
  const lag = n >= 8 && n <= 49
    ? 3
    : Math.max(1, Math.min(n - 1, Math.round((3 * (n - 1)) / 24)));
  let max = 0;
  for (let i = 0; i + lag < n; i++) {
    if (
      Number.isFinite(series[i]) && Number.isFinite(series[i + lag]) &&
      series[i]! > 0 && series[i + lag]! > 0
    ) {
      max = Math.max(max, Math.abs(series[i + lag]! - series[i]!));
    }
  }
  return max;
}

function trendScoreForDelta(delta24: number): number {
  const absDelta = Math.abs(delta24);
  if (delta24 < -0.5) {
    if (absDelta > 6.0) {
      return clampEngineScore(pieceLinear(absDelta, 6, 11, -0.25, -1.25));
    }
    if (absDelta > 3.0) {
      return clampEngineScore(pieceLinear(absDelta, 3, 6, 1.15, -0.25));
    }
    return clampEngineScore(pieceLinear(absDelta, 0.5, 3, 0.35, 1.15));
  }
  if (delta24 > 0.5) {
    if (delta24 <= 3.0) {
      return clampEngineScore(pieceLinear(delta24, 0.5, 3, 0.25, -0.15));
    }
    return clampEngineScore(pieceLinear(delta24, 3, 7.5, -0.15, -0.85));
  }
  return 0;
}

function smoothstep(edge0: number, edge1: number, value: number): number {
  if (edge0 === edge1) return value >= edge1 ? 1 : 0;
  const x = Math.max(0, Math.min(1, (value - edge0) / (edge1 - edge0)));
  return x * x * (3 - 2 * x);
}

export function normalizePressureDetailed(
  pressureHistoryMb: (number | null)[] | null | undefined,
): PressureNormalizeResult | null {
  // Hourly provider histories include 48 readings. A 24-hour interval needs
  // 25 endpoints. Trim BEFORE removing gaps so yesterday cannot fill missing hours.
  const window = (pressureHistoryMb ?? []).slice(-25);
  const series = window.filter((x): x is number =>
    typeof x === "number" && Number.isFinite(x) && x > 0
  );
  if (series.length < 2) return null;

  const quality: PressureHistoryQuality = series.length === 2
    ? "two_point"
    : series.length < 12
    ? "sparse"
    : "adequate";

  const latest = series[series.length - 1]!;
  const oldest = series[0]!;
  const delta24 = latest - oldest;
  const range24 = Math.max(...series) - Math.min(...series);
  const max3hSwing = maxRolling3hSwingMb(window);

  let directionChanges = 0;
  if (series.length >= 3) {
    let prevSign = 0;
    for (let i = 1; i < series.length; i++) {
      const d = series[i]! - series[i - 1]!;
      const s = d > 0.3 ? 1 : d < -0.3 ? -1 : 0;
      if (s !== 0 && prevSign !== 0 && s !== prevSign) directionChanges++;
      if (s !== 0) prevSign = s;
    }
  }

  // --- Volatile: erratic oscillation (genuinely bad) ---
  // Thresholds: range >= 8 mb over full window, OR 3h swing >= 4 mb, OR
  // 4+ direction reversals with >= 5 mb total range (oscillation, not just a front passage).
  // Note: max3hSwing threshold raised from 3.5 → 4.0 to avoid over-penalizing normal front passages.
  if (series.length >= 3) {
    if (
      range24 >= 8.0 ||
      max3hSwing >= 4.0 ||
      (directionChanges >= 4 && range24 >= 5.0)
    ) {
      // --- Recency check: if the last 4+ readings are tightly stable, the worst has passed.
      // Post-front settling often still fishes well; neutral (0) avoids systematic Fair caps on
      // legitimate "clearing" days while keeping full -2 for ongoing volatile windows.
      if (series.length >= 6) {
        const recentSlice = window.slice(-4).filter((x): x is number =>
          typeof x === "number" && Number.isFinite(x) && x > 0
        );
        const recentRange = Math.max(...recentSlice) - Math.min(...recentSlice);
        if (recentSlice.length === 4 && recentRange < 1.5) {
          const taper = Math.max(
            smoothstep(7.5, 8.5, range24),
            smoothstep(3.5, 4.5, max3hSwing),
            directionChanges >= 4 ? smoothstep(4.5, 5.5, range24) : 0,
          );
          const score = clampEngineScore(
            trendScoreForDelta(delta24) * (1 - taper) + 0.25 * taper,
          );
          return {
            quality,
            state: {
              label: "recently_stabilizing",
              score,
              detail: `prior range ${
                range24.toFixed(1)
              } mb, now settling (recent range ${recentRange.toFixed(1)} mb)`,
            },
          };
        }
      }

      const chaos = Math.max(range24 - 8, max3hSwing - 4, 0);
      const volScore = clampEngineScore(pieceLinear(chaos, 0, 6, -1.35, -2));
      return {
        quality,
        state: {
          label: "volatile",
          score: volScore,
          detail: `range ${range24.toFixed(1)} mb, 3h swing ${
            max3hSwing.toFixed(1)
          }`,
        },
      };
    }
  }

  const absDelta = Math.abs(delta24);

  // --- Falling pressure: the BEST fishing trigger ---
  if (delta24 < -0.5) {
    if (absDelta > 6.0) {
      const score = clampEngineScore(
        pieceLinear(absDelta, 6, 11, -0.25, -1.25),
      );
      return {
        quality,
        state: {
          label: "falling_hard",
          score,
          detail: `${delta24.toFixed(1)} mb/24h`,
        },
      };
    }
    if (absDelta > 3.0) {
      const score = clampEngineScore(
        pieceLinear(absDelta, 3, 6, 1.15, -0.25),
      );
      return {
        quality,
        state: {
          label: "falling_moderate",
          score,
          detail: `${delta24.toFixed(1)} mb/24h`,
        },
      };
    }
    const score = clampEngineScore(
      pieceLinear(absDelta, 0.5, 3, 0.35, 1.15),
    );
    return {
      quality,
      state: {
        label: "falling_slow",
        score,
        detail: `${delta24.toFixed(1)} mb/24h`,
      },
    };
  }

  if (delta24 > 0.5) {
    if (delta24 <= 3.0) {
      const score = clampEngineScore(
        pieceLinear(delta24, 0.5, 3, 0.25, -0.15),
      );
      return {
        quality,
        state: {
          label: "rising_slow",
          score,
          detail: `+${delta24.toFixed(1)} mb/24h`,
        },
      };
    }
    const score = clampEngineScore(
      pieceLinear(delta24, 3, 7.5, -0.15, -0.85),
    );
    return {
      quality,
      state: {
        label: "rising_fast",
        score,
        detail: `+${delta24.toFixed(1)} mb/24h`,
      },
    };
  }

  return {
    quality,
    state: {
      label: "stable_neutral",
      score: 0,
      detail: `${delta24.toFixed(1)} mb/24h`,
    },
  };
}

/** @deprecated use normalizePressureDetailed for quality-aware reliability */
export function normalizePressure(
  pressureHistoryMb: (number | null)[] | null | undefined,
): VariableState | null {
  const r = normalizePressureDetailed(pressureHistoryMb);
  return r?.state ?? null;
}
