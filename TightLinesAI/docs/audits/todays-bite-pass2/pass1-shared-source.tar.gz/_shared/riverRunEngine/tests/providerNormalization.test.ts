import { assert, assertEquals } from "jsr:@std/assert";
import {
  assembleConditionInputs,
  computeGaugeFreshness,
  computeWeatherFreshness,
  fetchRiverRunWeatherSnapshot,
  fetchUsgsInstantaneousValues,
  type NormalizedGaugeObservation,
  normalizeGaugeRead,
  normalizeWeatherSnapshot,
  parseNdbcWaterTemperature,
  parseUsgsInstantaneousValues,
  PERE_MARQUETTE_FALL_CHINOOK_RUN_PROFILE,
  PERE_MARQUETTE_RIVER_PROFILE,
  resolveAdminOverrideBand,
  resolveDataQuality,
  resolveFlowBand,
  resolveRainSignal,
  type WaterTemperatureSourceConfig,
} from "../index.ts";

Deno.test("Data Quality counts missing inputs monotonically without penalizing intentionally unused temperature", () => {
  const common = {
    gaugeFreshness: "fresh" as const,
    weatherFreshness: "fresh" as const,
    temperatureSourceType: "unavailable" as const,
    conditionsSuggestDaysUsable: 0,
    conditionsSuggestExpectedDays: 0,
  };
  assertEquals(
    resolveDataQuality({
      ...common,
      temperatureExpected: false,
      missingNonGaugeInputCount: 1,
    }).label,
    "Fresh",
  );
  assertEquals(
    resolveDataQuality({
      ...common,
      temperatureExpected: true,
      missingNonGaugeInputCount: 1,
    }).label,
    "Partial",
  );
  assertEquals(
    resolveDataQuality({
      ...common,
      temperatureExpected: true,
      missingNonGaugeInputCount: 2,
    }).label,
    "Limited",
  );
});

Deno.test("NDBC realtime text normalizes measured receiving-water temperature", () => {
  const source: WaterTemperatureSourceConfig = {
    sourceId: "oswego_45215_temperature",
    provider: "NOAA_NDBC",
    siteId: "45215",
    name: "Oswego buoy",
    role: "primary",
    priority: 1,
    sourceType: "receiving_water",
    maxAgeHours: 2,
    smoothingWindowHours: 3,
    minValidF: 32,
    maxValidF: 86,
    maxRateChangeFPerHour: 4,
    maxPeerDifferenceF: 6,
    reachNotes: "Measured offshore receiving-water context.",
    attribution: "NOAA NDBC station 45215.",
  };
  const parsed = parseNdbcWaterTemperature({
    source,
    text: [
      "#YY MM DD hh mm WDIR WSPD GST WVHT DPD APD MWD PRES ATMP WTMP DEWP VIS PTDY TIDE",
      "#yr mo dy hr mn degT m/s m/s m sec sec degT hPa degC degC degC nmi hPa ft",
      "2026 09 02 23 56 MM MM MM MM MM MM MM MM 23.2 22.1 MM MM MM MM",
      "2026 09 02 23 26 MM MM MM MM MM MM MM MM 23.0 21.9 MM MM MM MM",
    ].join("\n"),
  });
  assertEquals(parsed.rejectedObservationCount, 0);
  assertEquals(parsed.observations.length, 2);
  assertEquals(
    parsed.observations[0].source,
    "ndbc_realtime_standard_meteorological",
  );
  assertEquals(Math.round(parsed.observations[0].waterTempF * 10) / 10, 71.4);
});

Deno.test("Open-Meteo forecast retries one transient empty response", async () => {
  let calls = 0;
  const snapshot = await fetchRiverRunWeatherSnapshot({
    lat: 41.7166821,
    lon: -86.8597129,
    fetchedAtUtc: "2026-09-01T19:11:26.605Z",
    fetchFn: async () => {
      calls++;
      return {
        ok: true,
        json: async () =>
          calls === 1 ? { hourly: { time: [] } } : {
            timezone: "America/Chicago",
            hourly: {
              time: ["2026-09-01T14:00"],
              precipitation: [0],
              cloud_cover: [50],
              shortwave_radiation: [400],
              shortwave_radiation_clear_sky: [600],
            },
            daily: {
              time: ["2026-09-01"],
              precipitation_probability_max: [20],
            },
          },
      };
    },
  });
  assertEquals(calls, 2);
  assertEquals(snapshot?.hourly_activity_weather?.length, 1);
  assertEquals(snapshot?.weather_available, true);
});

Deno.test("USGS continuous fetch follows pagination before selecting latest high-cadence values", async () => {
  const requested: string[] = [];
  const feature = (minute: number) => ({
    properties: {
      monitoring_location_id: "USGS-04087000",
      parameter_code: "00060",
      time: new Date(Date.UTC(2026, 7, 20, 0, minute)).toISOString(),
      value: minute,
      unit_of_measure: "ft^3/s",
    },
  });
  const firstPage = Array.from({ length: 1000 }, (_, index) => feature(index));
  const secondPage = Array.from(
    { length: 50 },
    (_, index) => feature(1000 + index),
  );
  const payload = await fetchUsgsInstantaneousValues({
    siteId: "04087000",
    metrics: ["flow_cfs"],
    endAtUtc: "2026-08-27T00:00:00.000Z",
    period: "P7D",
    fetchFn: async (request) => {
      const url = String(request);
      requested.push(url);
      const pageTwo = new URL(url).searchParams.get("offset") === "1000";
      return {
        ok: true,
        json: async () => ({
          features: pageTwo ? secondPage : firstPage,
          links: pageTwo ? [] : [{
            rel: "next",
            href:
              "https://api.waterdata.usgs.gov/ogcapi/v0/collections/continuous/items?offset=1000",
          }],
        }),
      };
    },
  });
  const observations = parseUsgsInstantaneousValues(payload, "04087000");
  assertEquals(requested.length, 2);
  assertEquals(observations.length, 1050);
  assertEquals(observations.at(-1)?.flow_cfs, 1049);
});

function observation(
  observedAt: string,
  flowCfs: number,
): NormalizedGaugeObservation {
  return {
    provider: "USGS",
    siteId: "04122500",
    observedAt,
    flow_cfs: flowCfs,
    source: "usgs_continuous_values",
  };
}

function usgsPayload() {
  return {
    value: {
      timeSeries: [
        {
          variable: {
            variableCode: [{ value: "00060" }],
            variableName: "Discharge, cubic feet per second",
          },
          values: [{
            value: [
              { dateTime: "2026-09-20T10:00:00-04:00", value: "450" },
              { dateTime: "2026-09-21T10:00:00-04:00", value: "600" },
            ],
          }],
        },
        {
          variable: {
            variableCode: [{ value: "00065" }],
            variableName: "Gage height, feet",
          },
          values: [{
            value: [
              { dateTime: "2026-09-21T10:00:00-04:00", value: "4.25" },
            ],
          }],
        },
      ],
    },
  };
}

Deno.test("USGS parser maps discharge to flow_cfs and gauge height to gage_height_ft", () => {
  const observations = parseUsgsInstantaneousValues(usgsPayload(), "04122500");
  const latest = observations[observations.length - 1];

  assertEquals(latest.observedAt, "2026-09-21T14:00:00.000Z");
  assertEquals(latest.flow_cfs, 600);
  assertEquals(latest.gage_height_ft, 4.25);
});

Deno.test("USGS equipment faults fail closed and fresh numeric readings recover automatically", () => {
  const payload = usgsPayload();
  const series = payload.value.timeSeries[0].values[0].value;
  series.push(
    { dateTime: "2026-09-21T10:15:00-04:00", value: "Eqp" },
    { dateTime: "2026-09-21T10:30:00-04:00", value: "615" },
  );

  const observations = parseUsgsInstantaneousValues(payload, "04126740");
  assertEquals(
    observations.some((item) => item.observedAt.includes("14:15")),
    false,
  );
  assertEquals(observations.at(-1)?.flow_cfs, 615);
  assertEquals(observations.at(-1)?.observedAt, "2026-09-21T14:30:00.000Z");
});

Deno.test("modern USGS EQUIP-qualified zeros fail closed", () => {
  const observations = parseUsgsInstantaneousValues({
    features: [{
      properties: {
        monitoring_location_id: "USGS-04126740",
        parameter_code: "00060",
        time: "2026-08-24T23:00:00.000Z",
        value: 0,
        unit_of_measure: "ft^3/s",
        approval_status: "Provisional",
        qualifier: "EQUIP",
      },
    }],
  }, "04126740");

  assertEquals(observations, []);
});

Deno.test("Gauge freshness resolves fresh, stale, older_than_24h, and missing", () => {
  const observation: NormalizedGaugeObservation = {
    provider: "USGS",
    siteId: "04122500",
    observedAt: "2026-09-21T14:00:00.000Z",
    flow_cfs: 600,
    source: "usgs_continuous_values",
  };

  assertEquals(
    computeGaugeFreshness({
      observation,
      refreshAtUtc: "2026-09-21T18:00:00.000Z",
      maxAgeHours: 6,
    }),
    "fresh",
  );
  assertEquals(
    computeGaugeFreshness({
      observation,
      refreshAtUtc: "2026-09-22T02:00:00.000Z",
      maxAgeHours: 6,
    }),
    "stale",
  );
  assertEquals(
    computeGaugeFreshness({
      observation,
      refreshAtUtc: "2026-09-22T15:00:00.000Z",
      maxAgeHours: 6,
    }),
    "older_than_24h",
  );
  assertEquals(
    computeGaugeFreshness({
      observation: null,
      refreshAtUtc: "2026-09-22T15:00:00.000Z",
      maxAgeHours: 6,
    }),
    "missing",
  );
});

Deno.test("24h trend uses closest observation at or before 24h prior", () => {
  const observations: NormalizedGaugeObservation[] = [
    {
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-20T13:00:00.000Z",
      flow_cfs: 400,
      source: "usgs_continuous_values",
    },
    {
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-20T13:30:00.000Z",
      flow_cfs: 450,
      source: "usgs_continuous_values",
    },
    {
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-21T14:00:00.000Z",
      flow_cfs: 600,
      source: "usgs_continuous_values",
    },
  ];

  const read = normalizeGaugeRead({
    observations,
    siteId: "04122500",
    primaryMetric: "flow_cfs",
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    maxAgeHours: 6,
  });

  assertEquals(read.prior24h?.observedAt, "2026-09-20T13:30:00.000Z");
  assertEquals(read.flowTrend.rawSignal, "meaningful_rise");
});

Deno.test("missing 24h prior trend becomes unknown with reason code", () => {
  const read = normalizeGaugeRead({
    observations: [{
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-21T14:00:00.000Z",
      flow_cfs: 600,
      source: "usgs_continuous_values",
    }],
    siteId: "04122500",
    primaryMetric: "flow_cfs",
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    maxAgeHours: 6,
  });

  assertEquals(read.flowTrend.rawSignal, "unknown");
  assert(read.flowTrend.reasonCodes.includes("flow_trend_unknown"));
});

Deno.test("an observation far outside the 24h tolerance is not treated as a 24h comparison", () => {
  const read = normalizeGaugeRead({
    observations: [
      observation("2026-09-18T12:00:00.000Z", 500),
      observation("2026-09-20T20:00:00.000Z", 700),
    ],
    siteId: "04122500",
    primaryMetric: "flow_cfs",
    refreshAtUtc: "2026-09-20T20:10:00.000Z",
    maxAgeHours: 6,
    comparisonToleranceHours: 3,
  });
  assertEquals(read.prior24h, null);
  assertEquals(read.flowTrend.rawSignal, "unknown");
});

Deno.test("Weather freshness resolves fresh, stale, and missing", () => {
  assertEquals(
    computeWeatherFreshness({
      observedAt: "2026-09-21T12:00:00.000Z",
      refreshAtUtc: "2026-09-21T20:00:00.000Z",
      weatherAvailable: true,
    }),
    "fresh",
  );
  assertEquals(
    computeWeatherFreshness({
      observedAt: "2026-09-21T06:00:00.000Z",
      refreshAtUtc: "2026-09-21T20:00:00.000Z",
      weatherAvailable: true,
    }),
    "stale",
  );
  assertEquals(
    computeWeatherFreshness({
      observedAt: "2026-09-20T18:00:00.000Z",
      refreshAtUtc: "2026-09-21T20:00:00.000Z",
      weatherAvailable: true,
    }),
    "missing",
  );
  assertEquals(
    computeWeatherFreshness({
      observedAt: "2026-09-21T12:00:00.000Z",
      refreshAtUtc: "2026-09-21T20:00:00.000Z",
    }),
    "fresh",
  );
  assertEquals(
    computeWeatherFreshness({
      observedAt: "2026-09-21T12:00:00.000Z",
      refreshAtUtc: "2026-09-21T20:00:00.000Z",
      weatherAvailable: false,
    }),
    "missing",
  );
});

Deno.test("Rain totals distinguish observed dry from missing rain", () => {
  const dry = normalizeWeatherSnapshot({
    snapshot: {
      weather_available: true,
      fetched_at: "2026-09-21T19:00:00.000Z",
      hourly_precipitation_in: Array.from({ length: 72 }, (_, index) => ({
        time_utc: new Date(
          Date.parse("2026-09-18T21:00:00.000Z") + index * 3600_000,
        )
          .toISOString(),
        value: 0,
      })),
    },
    refreshAtUtc: "2026-09-21T20:00:00.000Z",
    localDate: "2026-09-21",
  });
  const missing = normalizeWeatherSnapshot({
    snapshot: {
      weather_available: true,
      fetched_at: "2026-09-21T19:00:00.000Z",
    },
    refreshAtUtc: "2026-09-21T20:00:00.000Z",
    localDate: "2026-09-21",
  });

  assertEquals(dry.rainSignal.rawSignal, "dry");
  assertEquals(missing.rainSignal.rawSignal, "missing_rain_data");
  assertEquals(
    resolveRainSignal({ rain48hIn: null, rain72hIn: null }).rawSignal,
    "missing_rain_data",
  );
});

Deno.test("Admin fishabilityBands override maps values to bands", () => {
  const bands = PERE_MARQUETTE_FALL_CHINOOK_RUN_PROFILE.fishabilityBands;

  assertEquals(resolveAdminOverrideBand(399.9, bands), "very_low");
  assertEquals(resolveAdminOverrideBand(400, bands), "low");
  assertEquals(resolveAdminOverrideBand(400.1, bands), "low");
  assertEquals(resolveAdminOverrideBand(480, bands), "low");
  assertEquals(resolveAdminOverrideBand(499.9, bands), "low");
  assertEquals(resolveAdminOverrideBand(500, bands), "normal_fishable");
  assertEquals(resolveAdminOverrideBand(500.1, bands), "normal_fishable");
  assertEquals(resolveAdminOverrideBand(524.9, bands), "normal_fishable");
  assertEquals(resolveAdminOverrideBand(525, bands), "ideal");
  assertEquals(resolveAdminOverrideBand(525.1, bands), "ideal");
  assertEquals(resolveAdminOverrideBand(749.9, bands), "ideal");
  assertEquals(resolveAdminOverrideBand(750, bands), "ideal");
  assertEquals(resolveAdminOverrideBand(750.1, bands), "high_fishable");
  assertEquals(resolveAdminOverrideBand(999.9, bands), "high_fishable");
  assertEquals(resolveAdminOverrideBand(1_000, bands), "high_fishable");
  assertEquals(resolveAdminOverrideBand(1_000.1, bands), "very_high");
  assertEquals(resolveAdminOverrideBand(1_599.9, bands), "very_high");
  assertEquals(resolveAdminOverrideBand(1_600, bands), "blown_out");
  assertEquals(resolveAdminOverrideBand(1_600.1, bands), "blown_out");
});

Deno.test("Fishability bands fail closed without matching audited absolute rules", () => {
  assertEquals(resolveFlowBand({ metric: "flow_cfs", value: 600 }), null);
  assertEquals(
    resolveFlowBand({
      metric: "gage_height_ft",
      value: 600,
      fishabilityBands:
        PERE_MARQUETTE_FALL_CHINOOK_RUN_PROFILE.fishabilityBands,
    }),
    null,
  );
});

Deno.test("Condition input assembler preserves reason codes and missingNonGaugeInputCount", () => {
  const gauge = normalizeGaugeRead({
    observations: [{
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-21T14:00:00.000Z",
      flow_cfs: 600,
      source: "usgs_continuous_values",
    }],
    siteId: "04122500",
    primaryMetric: "flow_cfs",
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    maxAgeHours: 6,
  });
  const weather = normalizeWeatherSnapshot({
    snapshot: {
      weather_available: true,
      fetched_at: "2026-09-21T14:30:00.000Z",
    },
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    localDate: "2026-09-21",
  });
  const inputs = assembleConditionInputs({
    river: PERE_MARQUETTE_RIVER_PROFILE,
    run: PERE_MARQUETTE_FALL_CHINOOK_RUN_PROFILE,
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    localDate: "2026-09-21",
    gauge,
    weather,
  });

  assert(inputs.rainReasonCodes.includes("rain_missing"));
  assert(inputs.flowReasonCodes.includes("flow_trend_unknown"));
  assert(inputs.temperatureReasonCodes.includes("temperature_neutral_missing"));
  assertEquals(inputs.missingNonGaugeInputCount, 2);
  assertEquals(inputs.flowBand, "ideal");
  assertEquals(inputs.sourceMetrics.weather?.provider, "OPEN_METEO");
  assertEquals(inputs.sourceMetrics.weather?.evidenceType, "modeled_grid");
  assertEquals(
    inputs.sourceMetrics.weather?.weatherPointId,
    "pm_baldwin_watershed_weather",
  );
});

Deno.test("Condition input assembler uses audited absolute bands", () => {
  const gauge = normalizeGaugeRead({
    observations: [{
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-21T14:00:00.000Z",
      flow_cfs: 600,
      source: "usgs_continuous_values",
    }],
    siteId: "04122500",
    primaryMetric: "flow_cfs",
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    maxAgeHours: 6,
  });
  const weather = normalizeWeatherSnapshot({
    snapshot: { fetched_at: "2026-09-21T14:30:00.000Z" },
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    localDate: "2026-09-21",
  });
  const inputs = assembleConditionInputs({
    river: PERE_MARQUETTE_RIVER_PROFILE,
    run: PERE_MARQUETTE_FALL_CHINOOK_RUN_PROFILE,
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    localDate: "2026-09-21",
    gauge,
    weather,
  });

  assertEquals(inputs.flowBand, "ideal");
});

Deno.test("Condition input assembler preserves unresolved flow band in source metrics", () => {
  const gauge = normalizeGaugeRead({
    observations: [{
      provider: "USGS",
      siteId: "04122500",
      observedAt: "2026-09-21T14:00:00.000Z",
      source: "usgs_continuous_values",
    }],
    siteId: "04122500",
    primaryMetric: "flow_cfs",
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    maxAgeHours: 6,
  });
  const weather = normalizeWeatherSnapshot({
    snapshot: {
      fetched_at: "2026-09-21T14:30:00.000Z",
      hourly_precipitation_in: [],
    },
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    localDate: "2026-09-21",
  });
  const inputs = assembleConditionInputs({
    river: PERE_MARQUETTE_RIVER_PROFILE,
    run: PERE_MARQUETTE_FALL_CHINOOK_RUN_PROFILE,
    refreshAtUtc: "2026-09-21T15:00:00.000Z",
    localDate: "2026-09-21",
    gauge,
    weather,
  });

  assertEquals(inputs.flowBand, undefined);
  assertEquals(inputs.sourceMetrics.gauge?.band, undefined);
});

Deno.test("Forecast data does not affect scoring inputs", () => {
  const base = normalizeWeatherSnapshot({
    snapshot: {
      weather_available: true,
      fetched_at: "2026-09-21T19:00:00.000Z",
      hourly_precipitation_in: [],
    },
    refreshAtUtc: "2026-09-21T20:00:00.000Z",
    localDate: "2026-09-21",
  });
  const withForecast = normalizeWeatherSnapshot({
    snapshot: {
      weather_available: true,
      fetched_at: "2026-09-21T19:00:00.000Z",
      hourly_precipitation_in: [],
      forecast_daily: [{ date: "2026-09-22", precip_chance_pct: 100 }],
    },
    refreshAtUtc: "2026-09-21T20:00:00.000Z",
    localDate: "2026-09-21",
  });

  assertEquals(withForecast.forecastDaily?.length, 1);
  assertEquals(withForecast.rainSignal, base.rainSignal);
});
